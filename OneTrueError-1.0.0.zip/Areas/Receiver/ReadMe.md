﻿Report receiver
================

The main purpose of this area is to just RECEIVE reports. No analytics is made at all. This distinction is made to make sure that all reports are stored successfully, even if something else in the system is having trouble.

The reports are later picked up by the ReportAnalyzer class library and are processed in it.

----

*This area should be considered to be stand alone and not related to anything else in the web site. It exists here just to make the installation experience easier.*

